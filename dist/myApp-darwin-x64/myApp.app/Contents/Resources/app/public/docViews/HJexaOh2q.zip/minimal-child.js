// Use this to adjust the logging output level.
if (!process.env.DEBUG) {
  process.env.DEBUG = "nqm-*";
}

// Create a log scoped to this module.
var log = require("debug")("nqm-process-minimal:index");

// Load the nqm output module for communicating progress and info back to the process host.
var output = require("nqm-process-utils").output;

// INFO output serves no function other than diagnostic 
output.write(output.INFO,"starting");

// PROGRESS output is mandatory, to inform the host of progress.
output.write(output.PROGRESS, 0);

// Simulate a process that has 10 steps.
var counter = 0;
setInterval(function() {
  log("tick");
  counter += 10;

  // Update the progress count at the host.
  output.write(output.PROGRESS,counter.toString());

  if (counter === 100) {
    log("tock");
    output.write(output.INFO,"complete");

    // Exit code 0 => finished with no errors.
    process.exit(0);
  }
}, 2500);
